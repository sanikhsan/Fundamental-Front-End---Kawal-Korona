import "regenerator-runtime";
import "./assets/styles/style.css";
import "./assets/styles/provinsi.css";
import "./assets/component/content.js";
import "./assets/component/footer.js";
import "./assets/component/jumbotron.js";
import "./assets/component/navbar.js";
import main from "./assets/script/main.js";

document.addEventListener("DOMContentLoaded", main);
