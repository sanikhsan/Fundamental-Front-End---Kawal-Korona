class Content extends HTMLElement {
    connectedCallback(){
        this.render();
    }

    render(){
        this.innerHTML = `
        <div class="album py-5" id="pencegahan">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="card mb-4 shadow-sm text-center">
                  <div class="iframe-container">
                    <iframe src="https://www.youtube.com/embed/hsls6DzwVGE" class="rounded" frameborder="0"></iframe>
                  </div>
                  <div class="card-body">
                    <p class="card-text"><h3>Tips terlindung dari Covid-19 Sesuai Petunjuk</h3></p>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="card mb-4 shadow-sm">
                  <img src="src/assets/gambar/gambar1.png" id="g1" class="img-fluid rounded mx-auto d-block" alt="">
                  <div class="card-body text-center">
                    <p class="card-text">Panduan 1.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="card mb-4 shadow-sm">
                  <img src="src/assets/gambar/gambar2.png" id="g2" class="img-fluid rounded mx-auto d-block" alt="">
                  <div class="card-body text-center">
                    <p class="card-text">Panduan 2.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="card mb-4 shadow-sm">
                  <img src="src/assets/gambar/gambar3.png" id="g3" class="img-fluid rounded mx-auto d-block" alt="">
                  <div class="card-body text-center">
                    <p class="card-text">Panduan 3.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="card mb-4 shadow-sm text-center">
                  <img src="src/assets/gambar/gambar4.png" id="g4" class="img-fluid rounded mx-auto d-block" alt="">
                  <div class="card-body">
                    <p class="card-text">Panduan 4.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
              <div class="card mb-4 shadow-sm text-center">
                <img src="src/assets/gambar/gambar5.png" id="g5" class="img-fluid rounded mx-auto d-block" alt="">
                <div class="card-body">
                  <p class="card-text">Panduan 5.</p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
            <div class="card mb-4 shadow-sm text-center">
              <img src="src/assets/gambar/gambar6.png" id="g6" class="img-fluid rounded mx-auto d-block" alt="">
              <div class="card-body">
                <p class="card-text">Panduan 6.</p>
              </div>
            </div>
          </div>
            </div>
          </div>
        </div>
        `;
    }
}
customElements.define("content-bar", Content);