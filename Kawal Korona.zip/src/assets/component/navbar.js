class Navbar extends HTMLElement{
    connectedCallback(){
        this.render();
    }

    render(){
        this.innerHTML = `
            <header>
                <div class="navbar navbar-dark shadow-sm bg-dark fixed-top">
                    <div class="container d-flex justify-content-between">
                        <a href="#" class="navbar-brand d-flex align-items-center">
                            <img src="src/assets/styles/logo.png" id="logo" width="30" height="30" class="d-inline-block align-top" alt=""><strong>&nbsp;Kawal Corona</strong></a>
                            <a href="#pencegahan"><button type="button" class="btn btn-light"><strong>Pencegahan</strong></button></button></a>
                    </div>
                </div>
            </header>
            `
    }
}

customElements.define('navbar-bar',Navbar);