class Jumbotron extends HTMLElement{
    connectedCallback(){
        this.render();
    }

    render(){
        this.innerHTML = `
            <section class="jumbotron text-center">
                <div class="container">
                    <h1>Kawal Statistik Virus COVID-19</h1>
                    <p class="lead text-muted">Pantau Statistik Penularan Covid-19 di Indonesia dan Negara Larinnya<br>#STAYATHOME #WORKFROMHOME.</p>
                    <button class="btn btn-primary" type="button" data-toggle="collapse" data-target=".asean">Data Negara Asean</button>
                    <a href="#" class="btn btn-secondary my-2" data-toggle="collapse" data-target=".indones">Data Negara Indonesia</a>
                </div>
            </section>
            `
    }
}

customElements.define('jumbotron-bar',Jumbotron);