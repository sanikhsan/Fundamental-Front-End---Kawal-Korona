import "../datas/country-list.js";
import "../datas/prov-list.js";
import countrys from "../datas/countrys.js";
import provys from "../datas/provys.js";
import gambar1 from "../gambar/gambar1.png";
import gambar2 from "../gambar/gambar2.png";
import gambar3 from "../gambar/gambar3.png";
import gambar4 from "../gambar/gambar4.png";
import gambar5 from "../gambar/gambar5.png";
import gambar6 from "../gambar/gambar6.png";
import logo from "../gambar/logo.png";
document.querySelector('#g1').src = gambar1;
document.querySelector('#g2').src = gambar2;
document.querySelector('#g3').src = gambar3;
document.querySelector('#g4').src = gambar4;
document.querySelector('#g5').src = gambar5;
document.querySelector('#g6').src = gambar6;
document.querySelector('#logo').src = logo;


function main(){

    const api_url = 'https://covid19.mathdro.id/api';
    const api_indo = 'https://covid19.mathdro.id/api/countries/indonesia';


        const showIndo = async () => {
            const res_indo = await fetch(api_indo);
            const statis_indo = await res_indo.json();
            const SummaryDataIndonesia = document.querySelector("summary-indo");
            SummaryDataIndonesia.innerHTML = `
              <div class="album py-4 bg-light">
                <div class="container">
                  <div class="col-md-10 text-center mx-auto">
                    <div class="card">
                      <img src="https://www.europol.europa.eu/sites/default/files/images/editor/covid-page-banner.png" class="mx-auto" width="100%" alt="statistik covid-19 negara indonesia">
                      <h3><u>DATA STATISTIK COVID-19 INDONESIA</u></h3>
                      <div class="card-body">
                        <table class="table table-dark">
                            <thead>
                                <tr>
                                    <th>POSITIF</th>
                                    <th>SEMBUH</th>
                                    <th>MENINGGAL</th>
                                </tr>
                            </thead>
                            <tbody class="table table-light">
                              <tr>
                                  <td id="plus">${statis_indo.confirmed.value}</td>
                                  <td id="heal">${statis_indo.recovered.value}</td>
                                  <td id="dead">${statis_indo.deaths.value}</td>
                              </tr>
                            </tbody>
                        </table>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">Last Update : ${statis_indo.lastUpdate}</small>
                            </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>`;
          }
          showIndo();

        const getData = async () => {
            const response = await fetch(api_url);
            const statistik = await response.json();

            const SummaryDataElement = document.querySelector("summary-list");
                SummaryDataElement.innerHTML = `
                  <div class="album py-4 bg-light">
                    <div class="container">
                      <div class="col-md-10 text-center mx-auto">
                        <div class="card mb-7 shadow-sm">
                          <img src="https://www.europol.europa.eu/sites/default/files/images/editor/covid-page-banner.png" class="mx-auto" width="100%" alt="">
                          <h3><u>DATA STATISTIK COVID-19 SEMUA NEGARA</u></h3>
                            <div class="card-body">
                                <table class="table table-dark">
                                    <thead>
                                        <tr>
                                            <th>POSITIF</th>
                                            <th>SEMBUH</th>
                                            <th>MENINGGAL</th>
                                        </tr>
                                    </thead>
                                      <tbody class="table table-light">
                                          <tr>
                                              <td id="plus">${statistik.confirmed.value}</td>
                                              <td id="heal">${statistik.recovered.value}</td>
                                              <td id="dead">${statistik.deaths.value}</td>
                                          </tr>
                                      </tbody>
                                </table>
                                <div class="d-flex justify-content-between align-items-center">
                                  <small class="text-muted">Last Update : ${statistik.lastUpdate}</small>
                                </div>
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>`;
          }
          getData();

        const getNegara = async () => {
          const NegaraListElement = document.createElement("country-list");
          NegaraListElement.countrysi = countrys;

          const negara = document.querySelector('country-list')
          negara.appendChild(NegaraListElement);
          }
          getNegara();

        const getProv = async () => {
          const ProvListElement = document.createElement("prov-list");
          ProvListElement.provinces = provys;
  
          const provinsi = document.querySelector("prov-list")
          provinsi.appendChild(ProvListElement);
          }
          getProv();

}

export default main;