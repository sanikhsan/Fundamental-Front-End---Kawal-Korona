import './country-item.js';

class CountryList extends HTMLElement {
    set countrysi(countrysi){
        this._countrysi = countrysi;
        this.render();
    }

    render(){
        this._countrysi.forEach(country => {
            const countryItemElement = document.createElement("country-item");
            countryItemElement.country = country;
            this.appendChild(countryItemElement);
        })
    }

}
window.customElements.define("country-list", CountryList);