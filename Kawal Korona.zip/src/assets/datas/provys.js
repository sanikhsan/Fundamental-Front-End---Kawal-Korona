const provys = [
    {
        name : "DKI Jakarta",
        confirmed : "7.690",
        recovered : "2.607",
        deaths : "523"
    },
    {
        name : "Jawa Barat",
        confirmed : "2.354",
        recovered : "719",
        deaths : "155"
    },
    {
        name : "Jawa Timur",
        confirmed : "5.408",
        recovered : "1.089",
        deaths : "437"
    },
    {
        name : "Jawa Tengah",
        confirmed : "1.479",
        recovered : "372",
        deaths : "71"
    },
    {
        name : "Yogyakarta",
        confirmed : "237",
        recovered : "174",
        deaths : "8"
    },
    {
        name : "Madura",
        confirmed : "5.408",
        recovered : "1.089",
        deaths : "437"
    },
    {
        name : "Papua",
        confirmed : "875",
        recovered : "78",
        deaths : "7"
    },
    {
        name : "Banten",
        confirmed : "965",
        recovered : "279",
        deaths : "69"
    }
];
export default provys;