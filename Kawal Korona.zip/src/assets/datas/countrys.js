const countrys = [
    {
        name : "Indonesia",
        confirmed : "28.818",
        recovered : "8.892",
        deaths : "1.721"
    },
    {
        name : "Brunei Darussalam",
        confirmed : "141",
        recovered : "138",
        deaths : "2"
    },
    {
        name : "Kamboja",
        confirmed : "125",
        recovered : "123",
        deaths : "0"
    },
    {
        name : "Laos",
        confirmed : "19",
        recovered : "6",
        deaths : "0"
    },
    {
        name : "Filipina",
        confirmed : "20.382",
        recovered : "4.248",
        deaths : "984"
    },
    {
        name : "Singapura",
        confirmed : "36.922",
        recovered : "23.582",
        deaths : "24"
    },
    {
        name : "Thailand",
        confirmed : "3.101",
        recovered : "2.968",
        deaths : "58"
    },
    {
        name : "Vietnam",
        confirmed : "328",
        recovered : "293",
        deaths : "0"
    },
    {
        name : "Malaysia",
        confirmed : "8.247",
        recovered : "6.559",
        deaths : "115"
    },
    {
        name : "Myanmar",
        confirmed : "233",
        recovered : "145",
        deaths : "6"
    }
];

export default countrys;