class CountryItem extends HTMLElement{
    set country(country){
        this._country = country;
        this.render();
    }

    render(){
        this.innerHTML = `
        <div class="col-md-5 py-3 text-center mx-auto">
          <div class="card shadow-sm">
            <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: Thumbnail"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">${this._country.name}</text></svg>
            <div class="card-body">
                <table class="table table-dark">
                <thead>
                    <tr>
                        <th>POSITIF</th>
                        <th>SEMBUH</th>
                        <th>MENINGGAL</th>
                    </tr>
                </thead>
                <tbody class="table table-light">
                <tr>
                    <td>${this._country.confirmed}</td>
                    <td>${this._country.recovered}</td>
                    <td>${this._country.deaths}</td>
                </tr>
                </tbody>
                </table>
            </div>
          </div>
        </div>`
    }
}
customElements.define("country-item", CountryItem);